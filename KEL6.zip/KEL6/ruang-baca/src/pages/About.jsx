import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AOS from 'aos';
import 'aos/dist/aos.css';
import './About.css';

function About() {
  const navigate = useNavigate();
  const [bgClass, setBgClass] = useState('bg-light');

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });

    const handleScroll = () => {
      const scrollY = window.scrollY;
      if (scrollY < 200) {
        setBgClass('bg-light');
      } else if (scrollY >= 200 && scrollY < 600) {
        setBgClass('bg-mid');
      } else {
        setBgClass('bg-dark');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className={`about-container ${bgClass}`}>
      <div className="about-header">
        <button onClick={() => navigate(-1)}>←</button>
        <h2>ABOUT</h2>
      </div>

      <img
        src="/homepage-image.jpg"
        alt="Gambar Utama"
        className="about-image"
        data-aos="zoom-in"
      />

      <div className="about-content">
        <h3 data-aos="fade-up">Tentang Kami :</h3>
        <p data-aos="fade-up">
          Ruang Baca adalah komunitas literasi yang menyediakan tempat nyaman untuk membaca, berdiskusi,
          dan berbagi pengetahuan. Didirikan pada tahun 2025, kami berkomitmen untuk meningkatkan minat
          baca dikalangan masyarakat, terutama generasi muda.
        </p>

        <div className="about-vision-mission">
          <div data-aos="fade-right">
            <h4>Visi</h4>
            <p>Menjadi pusat literasi yang inklusif dan inspiratif di Indonesia</p>
          </div>
          <div data-aos="fade-left">
            <h4>Misi</h4>
            <ul>
              <li>Menyediakan ruang baca yang nyaman dan gratis</li>
              <li>Menyelenggarakan kegiatan literasi seperti diskusi buku, bedah karya, dan kelas menulis</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
