import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

import agama from "../assets/agama.webp";
import fiksi1 from "../assets/fiksi.jpg";
import prog1 from "../assets/pemrograman.jpg";
import olahraga1 from "../assets/olahraga.jpg";

const bookData = [
  {
    id: 0,
    title: "Agama untuk Remaja",
    image: agama,
    description: "Buku ini membahas dasar-dasar agama yang mudah dipahami.",
    penulis: "Ahmad Salim",
    tahun: 2021,
    halaman: 120,
    penerbit: "Penerbit Ilmu Berkah",
    pdf: "#"
  },
  {
    id: 1,
    title: "Novel Fiksi",
    image: fiksi1,
    description: "Sebuah kisah fiksi penuh imajinasi dan petualangan.",
    penulis: "Rina Maharani",
    tahun: 2020,
    halaman: 220,
    penerbit: "Pustaka Fantasi",
    pdf: "#"
  },
  {
    id: 2,
    title: "Pemrograman Dasar",
    image: prog1,
    description: "Pelajari dasar-dasar coding dengan cara yang menyenangkan.",
    penulis: "Budi Santosa",
    tahun: 2023,
    halaman: 310,
    penerbit: "Tekno Media",
    pdf: "#"
  },
  {
    id: 3,
    title: "Olahraga Sehat",
    image: olahraga1,
    description: "Panduan menjaga kebugaran dan kesehatan tubuh.",
    penulis: "Fitri Andini",
    tahun: 2019,
    halaman: 180,
    penerbit: "Sehat Press",
    pdf: "#"
  },
];

const DetailBuku = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const book = bookData[parseInt(id)];

  if (!book) {
    return <div style={{ textAlign: "center", marginTop: "100px" }}>Buku tidak ditemukan 😢</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      style={{ padding: "40px", backgroundColor: "#f9fafb", minHeight: "100vh" }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
        <button
          onClick={() => navigate(-1)}
          style={{ background: "#4f46e5", color: "white", border: "none", padding: "10px 20px", borderRadius: "8px", cursor: "pointer" }}
        >
          ← Kembali
        </button>
        <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "bold" }}>Detail Buku</h2>
      </div>

      <div style={{ display: "flex", gap: "40px", alignItems: "flex-start", flexWrap: "wrap" }}>
        <motion.div
          initial={{ x: -50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <img src={book.image} alt={book.title} style={{ width: "300px", borderRadius: "12px" }} />
          <a href={book.pdf} target="_blank" rel="noreferrer">
            <button style={{ marginTop: "20px", padding: "10px 20px", backgroundColor: "#10b981", color: "white", border: "none", borderRadius: "8px", cursor: "pointer" }}>
              Lihat Buku 📖
            </button>
          </a>
        </motion.div>

        <motion.div
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          style={{ maxWidth: "600px" }}
        >
          <h2>{book.title}</h2>
          <p style={{ fontSize: "16px", margin: "10px 0" }}>{book.description}</p>
          <p><strong>Penulis:</strong> {book.penulis}</p>
          <p><strong>Tahun Terbit:</strong> {book.tahun}</p>
          <p><strong>Jumlah Halaman:</strong> {book.halaman}</p>
          <p><strong>Penerbit:</strong> {book.penerbit}</p>
        </motion.div>
      </div>

      <footer style={{ textAlign: "center", marginTop: "60px", borderTop: "1px solid #ddd", paddingTop: "20px", fontSize: "14px" }}>
        <i>Created by Kelompok 6</i>
        <div style={{ margin: "10px 0" }}>
          <a href="/" style={{ margin: "0 10px" }}>HOME</a>
          <a href="/about" style={{ margin: "0 10px" }}>ABOUT</a>
          <a href="/category" style={{ margin: "0 10px" }}>CATEGORY</a>
          <a href="/contact" style={{ margin: "0 10px" }}>CONTACT</a>
        </div>
        <p>© 2025 Ruang Baca Digital. Semua hak dilindungi</p>
      </footer>
    </motion.div>
  );
};

export default DetailBuku;
