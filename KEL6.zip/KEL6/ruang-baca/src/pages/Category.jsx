import React from 'react';

const Category = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Kategori Buku 📚</h1>
      <p className="text-lg text-gray-700">
        Di halaman ini, kamu bisa menjelajahi berbagai kategori buku yang tersedia, seperti fiksi, non-fiksi, pelajaran, dan lainnya.
      </p>
    </div>
  );
};

export default Category;
