import React from 'react';
import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center">
      <div className="flex items-center gap-2">
        <img src="/logo.png" alt="Logo" className="w-8 h-8" />
        <h1 className="text-xl font-bold text-gray-800">RUANG BACA</h1>
      </div>
      <div className="space-x-6">
        <NavLink to="/" className={({ isActive }) => isActive ? "text-blue-700 font-semibold" : "text-gray-700"}>Home</NavLink>
        <NavLink to="/about" className={({ isActive }) => isActive ? "text-blue-700 font-semibold" : "text-gray-700"}>About</NavLink>
        <NavLink to="/category" className={({ isActive }) => isActive ? "text-blue-700 font-semibold" : "text-gray-700"}>Category</NavLink>
        <NavLink to="/contact" className={({ isActive }) => isActive ? "text-blue-700 font-semibold" : "text-gray-700"}>Contact</NavLink>
      </div>
    </nav>
  );
};

export default Navbar;
